package Model;

public class Options {

}
